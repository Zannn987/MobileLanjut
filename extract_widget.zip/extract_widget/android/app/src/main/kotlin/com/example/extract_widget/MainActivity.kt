package com.example.extract_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
