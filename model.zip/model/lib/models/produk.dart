class Produk {
  String nama;
  String imageurl;
  int harga;
  String desc;

  Produk(this.imageurl, this.nama, this.harga, this.desc);
}
