package com.example.provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
