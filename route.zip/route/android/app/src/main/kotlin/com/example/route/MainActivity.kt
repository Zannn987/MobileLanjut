package com.example.route

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
