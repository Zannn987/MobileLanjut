import 'package:flutter/material.dart';

void main() {
  runApp(KalkulatorApp());
}

class KalkulatorApp extends StatelessWidget {
  const KalkulatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Kalkulator(),
    );
  }
}

class Kalkulator extends StatefulWidget {
  const Kalkulator({super.key});

  @override
  _KalkulatorState createState() => _KalkulatorState();
}

class _KalkulatorState extends State<Kalkulator> {
  final TextEditingController angka1Controller = TextEditingController();
  final TextEditingController angka2Controller = TextEditingController();
  double hasil = 0;

  void hitung(String operasi) {
    double angka1 = double.tryParse(angka1Controller.text) ?? 0;
    double angka2 = double.tryParse(angka2Controller.text) ?? 0;

    setState(() {
      if (operasi == '+') {
        hasil = angka1 + angka2;
      } else if (operasi == '-') {
        hasil = angka1 - angka2;
      } else if (operasi == '*') {
        hasil = angka1 * angka2;
      } else if (operasi == '/') {
        hasil = angka2 != 0 ? angka1 / angka2 : 0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kalkulator Sederhana'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: angka1Controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Angka 1',
              ),
            ),
            TextField(
              controller: angka2Controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Angka 2',
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => hitung('+'),
                  child: const Text('+'),
                ),
                ElevatedButton(
                  onPressed: () => hitung('-'),
                  child: const Text('-'),
                ),
                ElevatedButton(
                  onPressed: () => hitung('*'),
                  child: const Text('*'),
                ),
                ElevatedButton(
                  onPressed: () => hitung('/'),
                  child: const Text('/'),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              'Hasil: $hasil',
              style: const TextStyle(fontSize: 24),
            ),
          ],
        ),
      ),
    );
  }
}
