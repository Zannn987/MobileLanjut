import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text("My App"),
        ),
        body: ListView(
          padding: const EdgeInsets.all(8),
          scrollDirection: Axis.horizontal,
          children: [
            Container(
              width: 30,
              height: 30,
              color: Colors.green,
              child: const Center(
                child: Text('Entri A'),
              ),
            ),
            Container(
              width: 30,
              height: 30,
              color: Colors.yellow,
              child: const Center(
                child: Text('Entri B'),
              ),
            ),
            Container(
              height: 30,
              width: 30,
              color: Colors.black12,
              child: const Center(
                child: Text('Entri C'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
