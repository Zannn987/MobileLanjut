package com.example.flutter_stateless

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
